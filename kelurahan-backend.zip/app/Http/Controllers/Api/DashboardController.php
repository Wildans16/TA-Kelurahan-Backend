<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Permohonan;
use App\Models\Layanan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function stats(Request $request)
    {
        $days = $request->get('days', 7);
        $startDate = now()->subDays($days);

        $stats = [
            'total_permohonan' => Permohonan::where('created_at', '>=', $startDate)->count(),
            'permohonan_selesai' => Permohonan::where('created_at', '>=', $startDate)
                                            ->where('status', 'selesai')->count(),
            'permohonan_proses' => Permohonan::where('created_at', '>=', $startDate)
                                           ->where('status', 'proses')->count(),
            'permohonan_baru' => Permohonan::where('created_at', '>=', $startDate)
                                         ->where('status', 'baru')->count(),
        ];

        $recentApplications = Permohonan::with('layanan')
                                     ->orderBy('created_at', 'desc')
                                     ->limit(5)
                                     ->get();

        $popularServices = Layanan::select('layanan.nama')
                                ->selectRaw('COUNT(permohonan.id) as count')
                                ->leftJoin('permohonan', 'layanan.id', '=', 'permohonan.layanan_id')
                                ->where('permohonan.created_at', '>=', $startDate)
                                ->groupBy('layanan.id', 'layanan.nama')
                                ->orderBy('count', 'desc')
                                ->limit(4)
                                ->get();

        return response()->json([
            'success' => true,
            'data' => [
                'stats' => $stats,
                'recent_applications' => $recentApplications,
                'popular_services' => $popularServices
            ]
        ]);
    }
}
