<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Permohonan;
use App\Models\StatusTracking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class PermohonanController extends Controller
{
    public function index(Request $request)
    {
        $query = Permohonan::with(['layanan']);

        if ($request->has('status') && $request->status !== 'all') {
            $query->where('status', $request->status);
        }

        if ($request->has('layanan') && $request->layanan !== 'all') {
            $query->whereHas('layanan', function ($q) use ($request) {
                $q->where('nama', 'like', '%' . $request->layanan . '%');
            });
        }

        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('nama', 'like', '%' . $request->search . '%')
                  ->orWhere('nik', 'like', '%' . $request->search . '%')
                  ->orWhere('nomor_registrasi', 'like', '%' . $request->search . '%');
            });
        }

        $permohonan = $query->orderBy('created_at', 'desc')
                           ->paginate($request->get('per_page', 15));

        return response()->json([
            'success' => true,
            'data' => $permohonan
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'layanan_id' => 'required|exists:layanan,id',
            'nama' => 'required|string|max:255',
            'nik' => 'required|string|size:16',
            'tempat_lahir' => 'required|string|max:255',
            'tanggal_lahir' => 'required|date',
            'jenis_kelamin' => 'required|in:Laki-laki,Perempuan',
            'alamat' => 'required|string',
            'rt' => 'required|string|max:3',
            'rw' => 'required|string|max:3',
            'no_hp' => 'required|string|max:15',
            'email' => 'required|email|max:255',
            'keperluan' => 'required|string',
            'keterangan' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();
        try {
            // Buat permohonan
            $permohonan = Permohonan::create($request->all());

            // Buat status tracking awal
            $statusSteps = [
                'Pengajuan Diterima',
                'Verifikasi Dokumen',
                'Proses Persetujuan',
                'Selesai - Siap Diambil'
            ];

            foreach ($statusSteps as $index => $step) {
                StatusTracking::create([
                    'permohonan_id' => $permohonan->id,
                    'step' => $step,
                    'tanggal' => $index === 0 ? now() : null,
                    'completed' => $index === 0,
                ]);
            }

            // Set estimasi selesai (3 hari kerja)
            $estimasi = now()->addDays(3);
            $permohonan->update(['estimasi_selesai' => $estimasi]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Permohonan berhasil dibuat',
                'data' => [
                    'nomor_registrasi' => $permohonan->nomor_registrasi,
                    'permohonan' => $permohonan->load(['layanan', 'statusTracking'])
                ]
            ], 201);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message' => 'Gagal membuat permohonan',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function show($id)
    {
        $permohonan = Permohonan::with(['layanan', 'berkas', 'statusTracking'])
                                ->find($id);

        if (!$permohonan) {
            return response()->json([
                'success' => false,
                'message' => 'Permohonan tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $permohonan
        ]);
    }

    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:baru,proses,selesai,ditolak',
            'catatan' => 'nullable|string',
            'step' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        $permohonan = Permohonan::find($id);

        if (!$permohonan) {
            return response()->json([
                'success' => false,
                'message' => 'Permohonan tidak ditemukan'
            ], 404);
        }

        DB::beginTransaction();
        try {
            $permohonan->update([
                'status' => $request->status,
                'catatan' => $request->catatan
            ]);

            // Update status tracking jika ada step
            if ($request->step) {
                $tracking = StatusTracking::where('permohonan_id', $id)
                                        ->where('step', $request->step)
                                        ->first();
                if ($tracking) {
                    $tracking->update([
                        'completed' => true,
                        'tanggal' => now()
                    ]);
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Status permohonan berhasil diupdate',
                'data' => $permohonan->load(['statusTracking'])
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'success' => false,
                'message' => 'Gagal mengupdate status',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
