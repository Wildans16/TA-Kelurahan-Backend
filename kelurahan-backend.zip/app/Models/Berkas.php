<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Berkas extends Model
{
    use HasFactory;

    protected $table = 'berkas';

    protected $fillable = [
        'permohonan_id',
        'jenis_berkas',
        'nama_file',
        'path',
        'mime_type',
        'size',
    ];

    public function permohonan()
    {
        return $this->belongsTo(Permohonan::class);
    }

    public function getUrlAttribute()
    {
        return asset('storage/' . $this->path);
    }
}
