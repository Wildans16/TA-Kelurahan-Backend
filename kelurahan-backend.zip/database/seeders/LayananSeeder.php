<?php

namespace Database\Seeders;

use App\Models\Layanan;
use Illuminate\Database\Seeder;

class LayananSeeder extends Seeder
{
    public function run(): void
    {
        $layananData = [
            [
                'nama' => 'Surat Keterangan Domisili',
                'deskripsi' => 'Surat keterangan tempat tinggal untuk berbagai keperluan',
                'kategori' => 'surat',
                'persyaratan' => ['KTP asli', 'KK asli', 'Surat pengantar RT/RW'],
                'waktu_proses' => '1-2 hari kerja',
                'biaya' => 'Gratis',
                'status' => 'aktif'
            ],
            [
                'nama' => 'Surat Keterangan Tidak Mampu',
                'deskripsi' => 'Surat keterangan untuk bantuan sosial dan beasiswa',
                'kategori' => 'surat',
                'persyaratan' => ['KTP asli', 'KK asli', 'Surat pengantar RT/RW', 'Foto rumah'],
                'waktu_proses' => '2-3 hari kerja',
                'biaya' => 'Gratis',
                'status' => 'aktif'
            ],
            [
                'nama' => 'Pengantar KTP',
                'deskripsi' => 'Surat pengantar untuk pembuatan KTP baru atau perpanjangan',
                'kategori' => 'kependudukan',
                'persyaratan' => ['KK asli', 'Akta kelahiran', 'Pas foto 3x4', 'Surat pengantar RT/RW'],
                'waktu_proses' => '1 hari kerja',
                'biaya' => 'Gratis',
                'status' => 'aktif'
            ],
        ];

        foreach ($layananData as $layanan) {
            Layanan::create($layanan);
        }
    }
}
