<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\LayananController;
use App\Http\Controllers\Api\PermohonanController;
use App\Http\Controllers\Api\StatusController;
use App\Http\Controllers\Api\KontakController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\BerkasController;

// Public routes
Route::post('/login', [AuthController::class, 'login']);
Route::get('/layanan', [LayananController::class, 'index']);
Route::get('/layanan/{id}', [LayananController::class, 'show']);
Route::post('/permohonan', [PermohonanController::class, 'store']);
Route::post('/status/check', [StatusController::class, 'check']);
Route::post('/kontak', [KontakController::class, 'store']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    
    // Dashboard
    Route::get('/dashboard/stats', [DashboardController::class, 'stats']);
    
    // Admin routes
    Route::middleware('admin')->group(function () {
        // Layanan management
        Route::post('/layanan', [LayananController::class, 'store']);
        Route::put('/layanan/{id}', [LayananController::class, 'update']);
        Route::delete('/layanan/{id}', [LayananController::class, 'destroy']);
        
        // User management routes would go here
    });
    
    // Permohonan management (admin & petugas)
    Route::get('/permohonan', [PermohonanController::class, 'index']);
    Route::get('/permohonan/{id}', [PermohonanController::class, 'show']);
    Route::put('/permohonan/{id}/status', [PermohonanController::class, 'updateStatus']);
    
    // Berkas management
    Route::post('/berkas', [BerkasController::class, 'store']);
    Route::get('/berkas/{id}', [BerkasController::class, 'show']);
    Route::delete('/berkas/{id}', [BerkasController::class, 'destroy']);
    
    // Kontak management
    Route::get('/kontak', [KontakController::class, 'index']);
    Route::get('/kontak/{id}', [KontakController::class, 'show']);
    Route::put('/kontak/{id}', [KontakController::class, 'update']);
    Route::delete('/kontak/{id}', [KontakController::class, 'destroy']);
});
